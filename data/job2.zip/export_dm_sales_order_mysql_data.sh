#!/bin/bash

SQOOP_HOME=/opt/apps/sqoop
$SQOOP_HOME/bin/sqoop export \
--connect jdbc:mysql://qianfeng201:3306/sales_source_dm \
--username root \
--password-file hdfs://qphone01:9000/home/password.txt \
--export-dir /user/root/warehouse/sales_order_dm.db/sales_order_cnt \
--columns date,customer_number,customer_name,order_cnt1,order_amt1,order_cnt2,order_amt2 \
--input-fields-terminated-by '\001' \
--table sales_order_cnt \
--num-mappers 1
