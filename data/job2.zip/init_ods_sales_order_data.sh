#!/bin/bash

SQOOP_HOME=/opt/apps/sqoop

$SQOOP_HOME/bin/sqoop import \
--connect jdbc:mysql://qianfeng201:3306/sales_source \
--username root \
--password-file hdfs://qianfeng201:9000/home/password.txt \
--table customer \
--hive-import \
--hive-table sales_order_ods.customer \
--delete-target-dir \
--fields-terminated-by ',' \
--num-mappers 1 \
--as-textfile

$SQOOP_HOME/bin/sqoop import \
--connect jdbc:mysql://qianfeng201:3306/sales_source \
--username root \
--password-file hdfs://qianfeng201:9000/home/password.txt \
--table product \
--hive-import \
--hive-table sales_order_ods.product \
--delete-target-dir \
--fields-terminated-by ',' \
--num-mappers 1 \
--as-textfile

$SQOOP_HOME/bin/sqoop import \
--connect jdbc:mysql://qianfeng201:3306/sales_source \
--username root \
--password-file hdfs://qianfeng201:9000/home/password.txt \
--table sales_order \
--hive-import \
--hive-table sales_order_ods.sales_order \
--delete-target-dir \
--fields-terminated-by ',' \
--num-mappers 1 \
--as-textfile

