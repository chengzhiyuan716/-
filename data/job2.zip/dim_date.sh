#!/bin/bash

date1="2010-01-01"

tempdate=`date -d "$date1" +%F`
min=1
max=9999

while [ $min -le $max ]
do
        month=`date -d "$tempdate" +%m`
        month_name=`date -d "$tempdate" +%B`
        quarter=`echo $month | awk '{print int(($0-1)/3) + 1 }'`
        year=`date -d "$tempdate" +%Y`
        echo ${min}","${tempdate}","${month}","${month_name}","${quarter}","${year} >> /home/dim_date.csv
        tempdate=`date -d "+$min day $date1" +%F`
        min=`expr $min + 1`
        echo 'has import' $min 'lines'
		
done
hdfs dfs -rm /home/dim_date.csv
hdfs dfs -put /home/dim_date.csv /home
rm -rf /home/dim_date.csv